import java.lang.*;

public class Start
{
public static void main(String[] args)
{
 StoryBook s1 = new StoryBook();
 System.out.println("Details for s1 :");
 
 s1.setIsbn("12-453");
 s1.setBookTitle("A Time to Kill");
 s1.setAuthorName("Jhon Grisham");
 s1.setPrice(500.0);
 s1.setAvaiableQuantity(25);
 s1.setCategory("Thriller");
 s1.showDetails();

 System.out.println("Details for s2 :");

 StoryBook s2 = new StoryBook("4574-232", "Number the Stars", " Lois Lowri", 220.5, 60, "Story  Book" );
 s2.showDetails();

 System.out.println("Details for t1 :");

 TextBook t1 = new TextBook();
 t1.setIsbn("4536-67");
 t1.setBookTitle("Brave New World");
 t1.setAuthorName("Aldows Huksway");
 t1.setPrice(400.0);
 t1.setAvaiableQuantity(15);
 t1.setStandard(6);

 
}
}