import java.lang.*;

public class Book
{
    
private String isbn;
private String bookTitle;
private String authorName;
private double price;
private int availableQuantity;

public Book()
{

}
    
public Book( String ishan, String Title, String author, double bookprice, int Quantity )
{

    isbn = ishan;
    bookTitle = Title;
    authorName = author;
    price = bookprice;
    availableQuantity = Quantity;

}


public void setIsbn ( String isbn )
{

    isbn = isbn;

}
public void setBookTitle ( String bt )
{

    bookTitle = bt;

}
public void setAuthorName ( String an )
{

    authorName = an;

}
public void setPrice ( double p )
{

    price = p;

}
public void setAvailableQuantity ( int avaQ )
{

	availableQuantity = avaQ;

}

public String getIsbn()
{

    return isbn;

}
public String getBookTitle()
{

	return bookTitle;

}
public String getAuthorName()
{

    return authorName;

}
public double getPrice()
{

    return price;

}
public int getAvailableQuantity()
{

   return availableQuantity;

}


public void addQuantity ( int amount )
{

if ( amount > 0)
{

   availableQuantity = availableQuantity + amount;
   System.out.println (" Add availableQuantity : " + availableQuantity );

}
else 
{

   System.out.println (" Add availableQuantity : bad Quantity/Invalid ");

}

}
public void sellQuantity ( int amount )
{

    if ( amount > 0 && amount <= availableQuantity ){
    
       availableQuantity = availableQuantity - amount;
       System.out.println (" Sell availableQuantity : " + availableQuantity );
    
    }
    else 
	{
    
       System.out.println (" Sell availableQuantity : bad Quantity/Invalid ");
    
    }

}

public void showDetails()
{

    System.out.println("Isbn               : "+isbn);
    System.out.println("Book Title         : "+bookTitle);
    System.out.println("Author Name        : "+authorName);
    System.out.println("Price              : "+price);
    System.out.println("Available Quantity : "+availableQuantity);


}

}

