import java.lang.*;

public class Test

{
	public static void main(String[] args)
	
	{
		Student s1 = new Student();
		s1.setId(22464441);
		s1.setName("TRIDIB SARKAR");
		s1.setCgpa(3.54);
		s1.display();
		
	}
	
	
	
}