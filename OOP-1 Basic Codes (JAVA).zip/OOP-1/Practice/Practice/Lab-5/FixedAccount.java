public class FixedAccount extends Account
{
	public double interestRate;
    public int year;
    public FixedAccount()
	{
		
	}
    public FixedAccount(double fx)
	{
		fixedAccount=fx;
	}
    public Void setinterestRate(double ir)
	{
		interestRate=ir;
	}

    public double getinterestRate() 
{
	return interestRate;
}
    public void setyear(int y)
{
	year=y;
}
    public int getyear()
{
	return year;
}
    public void calculateInterestAmount()
{
	calculateInterestAmount=balance*year*interestRate;
	System.out.println("Interest: "+calculateInterestAmount);
}
}