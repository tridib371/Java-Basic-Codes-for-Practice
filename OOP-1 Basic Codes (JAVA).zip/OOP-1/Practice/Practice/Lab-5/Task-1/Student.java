public class Student
{
String name;
String id;
double cgpa;
Course c;
public void setname(String name)
{
	this.name=name;
}
public void setid(String id)
{
	this.id=id;
}
public void setcgpa(double cgpa)
{
	this.cgpa=cgpa;
}
public String getname()
{
	return name;
}
public String getid()
{
	return id;
}
public double getcgpa()
{
	return cgpa;
}
public void setCourse(Course c)
{
	this.c=c;
}
public Course getcourse()
{
	return c;
}
public Student(String name, String id,double cgpa)
{
	this.name=name;
	this.id=id;

	this.cgpa=cgpa;
}
public Student()
{
	
}
}