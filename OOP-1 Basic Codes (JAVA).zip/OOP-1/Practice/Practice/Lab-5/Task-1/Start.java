public class Start
{
public static void main(String args[])
{
	FixedAccount a1=new FixedAccount();
	System.out.println("Account Name:"+a1.getaccountName());
	System.out.println("Account Number:"+a1.getaccountNumber());
	System.out.println("Balance"+a1.getbalance());
	System.out.println("Year:"+a1.getyear());
	System.out.println("Interest Rate:"+a1.getinterestRate());
	a1.setyear(10);
	a1.setinterestRate(0.5);
	a1.setaccountName("Mahmudus Sami Maahi");
	a1.setaccountNumber("1234-12");
	a1.setbalance(1200);
	a1.calculateInterestAmount();
}
}