public class FixedAccount extends Account
{
	public double interestRate;
    public int year;
    FixedAccount()
	{
		
	}
    FixedAccount(double ir)
	{
		interestRat=ir;
	}
    public Void setinterestRate(double ir)
	{
		interestRate=ir;
	}

    public double getinterestRate() 
{
	return interestRate;
}
    public void setyear(int y)
{
	year=y;
}
    public int getyear()
{
	return year;
}
    public void calculateInterestAmount()
{
	calculateInterestAmount=balance*year*interestrate;
}
}