public class Course
{
	String cname;
	String cid;
	public void setcname(String cname)
	{
		this.cname=cname;
	}
	public void setcid(String cid)
	{
		this.cid=cid;
	}
	public Course()
	{
		
	}
	public String getcname()
	{
		return cname;
	}
	public String getcid()
	{
		return cid;
	}
	
	Course(String cname,String cid)
	{
		this.cname=cname;
		this.cid=cid;
	}
}