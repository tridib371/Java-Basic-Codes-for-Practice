public class Main
{
	public static void main(String args[])
	{
		Student s=new Student("ss","ww",1.22);
		Course c1=new Course("sss","sds");
		s.setCourse(c1);
	    System.out.println(s.getCourse().getcname());
	}
}