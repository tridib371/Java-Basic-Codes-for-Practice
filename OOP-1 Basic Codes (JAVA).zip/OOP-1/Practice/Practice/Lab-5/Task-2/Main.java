class Main
{
	public static void main(String args[])
	{
		System.out.println("--------------------=-----------=---------------=------------=---------");
		StoryBook sb=new StoryBook("223","Fantasitic 4","Mahmudus sami",8000.123,5,"Story Book");
		sb.setdiscountRate(9);
		sb.showDetails();
		sb.amount(4);
		System.out.println("-----------------------------------------------------");
		TextBook tb=new TextBook("12332","JAVA","Mahmudus Sami Maahi",9999,9,10);
		tb.setdiscountRate(5);
		tb.showDetails();
		tb.amount(3);
	}
}
		