public class StoryBook
{
public String isbn;
public String bookTitle;
public String authorName;
public double price;
public int availableQuantity;
public String category;
public static double discountRate;
public StoryBook( )
{
	
}
public StoryBook(String isbn, String bookTitle, String authorName, double price, int availableQuantity, String category)
{
	this.isbn=isbn;
	this.bookTitle=bookTitle;
	this.authorName=authorName;
	this.availableQuantity=availableQuantity;
	this.category=category;
	this.price=price;
}
public static void setdiscountRate(double rate)
{
	discountRate=rate;
}
public static double getdiscountRate( )
{
	return discountRate;
}
public void setisbn(String isbn)
{
	this.isbn=isbn;
}
public void setbookTitle(String bookTitle)
{
	this.bookTitle=bookTitle;
}
void setauthorName(String authorName)
{
	this.authorName=authorName;
}
public void setprice(double price)
{
	this.price=price;
}
public void setavaiableQuantity(int availableQuantity)
{
	this.availableQuantity=availableQuantity;
}
public void setcategory(String category)
{
	this.category=category;
}
public String getisbn( )
{
	return isbn;
}
public String getbookTitle( )
{
	return bookTitle;
}
public String getauthorName( )
{
	return authorName;
}
public double getprice( )
{
	return price;
}
public int getavailableQuantity( )
{
	return availableQuantity;
}
public String getcategory( )
{
	return category;
}
public void addQuantity(int amount)
{
	addQuantity+=amount;
	System.out.println("Add Quantity: "+addQuantity);
}
public void sellQuantity(int amount)
{
	sellQuantity-=amount;
	System.out.println("Sell Quantity: "+sellQuantity);
}
public void showDetails( )
{
	System.out.println("ISBN :"+isbn);
	System.out.println("Book Title :"+bookTitle);
	System.out.println("Author Name :"+authorName);
	System.out.println("Price :"+price);
	System.out.println("Available Quantity :"+availableQuantity);
	System.out.println("Category :"+category);
}
}