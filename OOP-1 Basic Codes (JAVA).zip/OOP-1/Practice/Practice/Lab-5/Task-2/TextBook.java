public class TextBook extends  StoryBook
{
public String isbn;
public String bookTitle;
public String authorName;
public double price;
public int availableQuantity;
public int standard;
public static double discountRate;
public TextBook( )
{
	
}
public TextBook(String isbn, String bookTitle, String authorName, double price, int availableQuantity,int standard)
{
	this.isbn=isbn;
	this.bookTitle=bookTitle;
	this.authorName=authorName;
	this.price=price;
	this.availableQuantity=availableQuantity;
	this.standard=standard;
}
public static void setdiscountRate(double rate)
{
	discountRate=rate;
}
public static double getdiscountRate( )
{
	return discountRate;
}
public void setisbn(String isbn)
{
	this.isbn=isbn;
}
public void setbookTitle(String bookTitle)
{
	this.bookTitle=bookTitle;
}
public void setauthorName(String authorName)
{
	this.authorName=authorName;
}
public void setprice(double price)
{
	this.price=price;
}
public void setavaiableQuantity(int availableQuantity)
{
	this.availableQuantity=availableQuantity;
}
public void setstandard(int standard)
{
	this.standard=standard;
}
public String getisbn( )
{
	return isbn;
}
public String getbookTitle( )
{
	return bookTitle;
}
public String getauthorName( )
{
	return authorName;
}
public double getprice( )
{
	return price;
}
public int getavailableQuantity( )
{
	return availableQuantity;
}
public int getstandard( )
{
	return standard;
}
public void addQuantity(int amount)
{
	addQuantity+=amount;
	System.out.println("Add Quantity: "+addQuantity);
}
public void sellQuantity(int amount)
{
	sellQuantity-=amount;
	System.out.println("Sell Quantity: "+sellQuantity);
}
public void showDetails( )
{
	System.out.println("ISBN :"+isbn);
	System.out.println("Book Title :"+bookTitle);
	System.out.println("Author Name :"+authorName);
	System.out.println("Price :"+price);
	System.out.println("Available Quantity :"+availableQuantity);
	System.out.println("Standard :"+standard);
}

}