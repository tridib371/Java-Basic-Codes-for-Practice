public class Account
{

public String accountName;
public String accountNumber;
public Double balance;
public Account()
{
	
}
public Account(String ana,String ano,double ba)
{
	accountName=ana;
	accountNumber=ano;
	balance=ba;
}
public void setaccountName(String ana)
{
	accountName=ana;
}
public void setaccountNumber(String ano)
{
	accountNumber=ano;
}
public void setbalance(double ba)
{
	balance=ba;
}
public String getaccountName()
{
	return accountName;
}
public String getaccountNumber()
{
	return accountNumber;
}
public Double getbalance()
{
	return balance;
}
}