public class Main
{
	public static void main(String args[])
	{

		Burger b=new Burger(12,123,"mmm");
		System.out.println(b.getnumberOfPatties());
		b.showDetails( );

		Burger b1=new Burger(123,12,"1234");
		System.out.println("Burger Patties: "+b1.getnumberOfPatties());
	    b1.showDetails();
		
        Pizza p=new Pizza("1121",12,"Tauhid");
		System.out.println(p.getsize());
		p.showDetails( );
		Pizza p1=new Pizza("111",1,"Tauhida");
		System.out.println(p1.getsize());
		p1.showDetails();
	}
}