public class Pizza extends FoodItem
{
	private String size;
    public Pizza( )
	{
		
	}
    public Pizza(String size, double price, String name)
	{
		super(price,name);
		this.size=size;
	}
    void setSize(String size)
	{
		this.size=size;
	}
    String getsize( )
	{
		return size;
	}
}