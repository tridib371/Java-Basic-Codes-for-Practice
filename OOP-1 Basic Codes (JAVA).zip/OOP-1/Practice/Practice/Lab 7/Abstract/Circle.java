class Circle implements Shape
{
	private double radius;
	
	/*Circle()
	{
	}
	Circle(double radius)
	{
		super(radius,radius);
	}*/
	
	void setradius(double radius)
	{
		radius=radius;
	}
	double getradius()
	{
		return radius;
	}
	public void displayArea()
	{
		double area=3.1416*getDim1()*getDim2();
		System.out.println("Circle Area is : "+area);
	}
}
