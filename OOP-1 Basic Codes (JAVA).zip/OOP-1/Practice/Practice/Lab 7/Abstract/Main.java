class Main
{
	public static void main(String args[])
	{
		Rectangle r=new Rectangle(10,4);
		Triangle  t=new Triangle(12,3);
		Circle    c=new Circle(8.0);
		r.displayArea();
		t.displayArea();
		c.displayArea();
	}
}