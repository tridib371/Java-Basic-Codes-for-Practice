class Triangle implements Shape 
{
	private double base;
	private double height;
	
	/*Triangle()
	{
	}
	Triangle(double base,double height)
	{
		super(base,height);
	}*/
	
	void setBase(double base)
	{
		base=base;
	}
	void setHeight(double dim2)
	{
		height=dim2;
	}
	double getBase()
	{
		return base;
	}
	double getHeight()
	{
		return height;
	}
	public void displayArea()
	{
		double area=0.5*getDim1()*getDim2();
		System.out.println("Triangle Area is : "+area);
	}
}
