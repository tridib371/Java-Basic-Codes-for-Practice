class Rectangle implements Shape 
{
	private double length;
	private double width;
	/*Rectangle()
	{
	}
	Rectangle(double length,double width)
	{
		super(length,width);
	}*/
	void setLength(double dim1)
	{
		length=dim1;
	}
	void setWidth(double dim2)
	{
		width=dim2;
	}
	double getLength()
	{
		return length;
	}
	double getWidth()
	{
		return width;
	}
	public void displayArea()
	{
		double area=getDim1()*getDim2();
		System.out.println("Rectangle Area is : "+area);
	}
}