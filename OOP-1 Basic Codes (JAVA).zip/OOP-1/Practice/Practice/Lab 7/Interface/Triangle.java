public class Triangle implements Shape 
{
	private double base;
	private double height;
	Triangle()
	{
	}
	Triangle(double base,double height)
	{
		this.base=base;
		this.height=height;
	}
	public void setDim1(double dim1)
	{
		base=dim1;
	}
	public void setDim2(double dim2)
	{
		height=dim2;
	}
	public double getDim1()
	{
		return base;
	}
	public double getDim2()
	{
		return height;
	}
	public void displayArea()
	{
		double area=0.5*getDim1()*getDim2();
		System.out.println("Triangle Area is : "+area);
	}
}
