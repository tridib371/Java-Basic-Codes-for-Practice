class Main
{
	public static void main(String args[])
	{
		Rectangle r=new Rectangle(123,45);
		Triangle  t=new Triangle(22.22,12);
		Circle    c=new Circle(3.0);
		t.displayArea();
		c.displayArea();
		r.displayArea();
	}
}