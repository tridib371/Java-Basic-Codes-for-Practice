public class Circle implements Shape
{
	private double radius;
	Circle()
	{
	}
	Circle(double radius)
	{
		this.radius=radius;
	}
	public void setDim1(double dim1)
	{
		radius=dim1;
	}
	public void setDim2(double dim2)
	{
		radius=dim1;
	}
	public double getDim1()
	{
		return radius;
	}
	public double getDim2()
	{
		return radius;
	}
	public void displayArea()
	{
		double area=3.1416*getDim1()*getDim2();
		System.out.println("Circle Area is : "+area);
	}
}
