public interface Shape
{
	double dim1=0.00;
	double dim2=0.00;
	public void setDim1(double dim1);
	public void setDim2(double dim2);
	public double getDim1();
	public double getDim2();
	public abstract void displayArea();
}
	