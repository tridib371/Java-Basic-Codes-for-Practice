public class Rectangle implements Shape 
{
	private double length;
	private double width;
	Rectangle()
	{
	}
	Rectangle(double length,double width)
	{
		this.length=length;
		this.width=width;
	}
	public void setDim1(double dim1)
	{
		length=dim1;
	}
	public void setDim2(double dim2)
	{
		width=dim2;
	}
	public double getDim1()
	{
		return length;
	}
	public double getDim2()
	{
		return width;
	}
	public void displayArea()
	{
		double area=getDim1()*getDim2();
		System.out.println("Rectangle Area is : "+area);
	}
}