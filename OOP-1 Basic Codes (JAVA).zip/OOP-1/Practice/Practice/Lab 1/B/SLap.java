class SLap
{
	public static void main(String args[])
{
	Code c=new Code(12,223,"Mahmudus Sami Maahi");
	c.diplayInfo();
}
}