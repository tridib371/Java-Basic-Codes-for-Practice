import java.lang.*;
public class Student 
{
	private int id;
	private String name;
	private double cgpa;
	public Student()
	{
		
	}
	public Student( String n,int i,double cg)
	{
		name=n;
		id=i;
		cgpa=cg;
	}
	public void display()
	{
		System.out.println("My name is : "+name);
		System.out.println("My ID is : "+id);
		System.out.println("My CGPA is : "+cgpa);
	}
	public void setName(String n)
	{
		name=n;
	}
	public String getName()
	{
		return name;
	}
	public void setID(int i)
	{
		id=i;
	}
	public int getID()
	{
		return id;
	}
	public void setCGPA(double cg)
	{
		cgpa=cg;
	}
	public double getCGPA()
	{
		return cgpa;
	}
}