public class Main
{
	public static void main(String args[])
	{
		Student s1=new Student();
		s1.setName("Maahi");
		s1.setID(236464381);
		s1.setCGPA(5.00);
		System.out.println("My name is : "+s1.getName());
		System.out.println("My ID 	is : "+s1.getID());
		System.out.println("My CGPA is : "+s1.getCGPA());
	}
}