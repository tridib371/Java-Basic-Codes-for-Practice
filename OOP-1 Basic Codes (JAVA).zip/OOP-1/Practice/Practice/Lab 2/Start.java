	public class Start
{
	public static void main(String args[])
	{

	Product p1=new Product();
	p1.setProductid("1234A");
	p1.setProductName("Life Is Hell");
	p1.setPrice(250.23);
	p1.setAvaiableQuantity(25);
	p1.showDetails();
	Product p2=new Product();
	p2.setProductid("1244A");
	p2.setProductName("Life Need Heal");
	p2.setPrice(230.23);
	p2.setAvaiableQuantity(22);
	p2.showDetails();
	Product p3=new Product();
	p3.setProductid("1254A");
	p3.setProductName("Life Called Duty");
	p3.setPrice(270.23);
	p3.setAvaiableQuantity(15);
	p3.showDetails();
	Product Arr[]=new Product[2];
	Arr[0]=p1;
	Arr[1]=p2;
	Arr[2]=p3;
	
	}
}