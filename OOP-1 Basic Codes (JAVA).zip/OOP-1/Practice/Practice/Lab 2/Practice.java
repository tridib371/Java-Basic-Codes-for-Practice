import java.lang.*;
public class Pratice
{
	public static void main(String args[])
	{
	private int nm;
	private double ms;
	public Pratice()
	{}
	
	public void Info()
	{
		System.out.println("Please Input The Value: "+nm);
		Scanner scan=new Scanner(System.in);
		double nm=scan.nextdouble();
		System.out.println("Please Input The Value: "+ms);
	}
	System.out.println("Please Input The Value: "+nm);
} 
}