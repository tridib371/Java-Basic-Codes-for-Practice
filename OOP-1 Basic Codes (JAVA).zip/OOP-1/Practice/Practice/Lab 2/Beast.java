import java.lang.*;
public class Beast
{
	public String name;
	public int id;
	public double balance;
	public double withdraw;
	public Beast()
	{
		
	}
	public Beast()
	{
		this.name=name;
		this.id=id;
		this.balance=balance;
	}
	public void setname(String name)
	{
		this.name=name;
	}
	public void setid(int id)
	{
		this.id=id;
	}
	public String getname()
	{
		return name;
	}
	public int getid()
	{
		return id;
	}
	public void setbalance(double balance)
	{
		this.balance=balance;
	}
	public double getbalance()
	{
		return balance;
	}
	public void showInfo()
	{
		System.out.println("Name: "+name);
		System.out.println("ID: "+id);
		System.out.println("Balance: "+balance);
	}
	public void withdraw(double withdraw)
	{
		this.withdraw=withdraw;
	}
	/*public void add(double add)
	{
		this.add=add;
	}*/
}