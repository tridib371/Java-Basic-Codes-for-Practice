public class Main
{
	public static void main(String args[])
	{
		Beast b=new Beast();
		b.setname("Mahmudus Sami Maahi");
		b.setid(12345);
		b.setbalance(500);
		System.out.println(b.getname());
		System.out.println(b.getid());
		System.out.println(b.getbalance());
		b.showInfo();
		b.withdraw=blance-50;
		b.withdraw();
		
		
	}
}