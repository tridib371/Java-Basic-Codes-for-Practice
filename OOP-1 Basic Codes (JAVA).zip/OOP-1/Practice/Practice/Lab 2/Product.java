public class Product
{
	private String productid;
	private String productName;
	private double price;
	private int avaiableQuantity;
	public void setProductid(String productid)
	{
		this.productid=productid;
	}
	public void setProductName(String productName)
	{
		this.productName=productName;
	}
	public void setPrice(double price)
	{
		this.price=price;
	}
	public void setAvaiableQuantity(int avaiableQuantity)
	{
		this.avaiableQuantity=avaiableQuantity;
	}
	public String getProductid()
	{
		return productid;
	}
	public String getProductName()
	{
		return productName;
	}
	public double getPrice()
	{
		return price;
	}
	public int getAvaiableQuantity()
	{
		return avaiableQuantity;
	}
	public Product()
	{
	}
	public void showDetails()
	{
		System.out.println("Product id is : "+productid);
		System.out.println("Product Name is : "+productName);
		System.out.println("Product Price is : "+price);
		System.out.println("Product Avaiable Quantity is : "+avaiableQuantity);
	}
}

