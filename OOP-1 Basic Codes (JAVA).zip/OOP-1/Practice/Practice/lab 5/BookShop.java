class BookShop
{
	private String name;
	Book books[];
	BookShop()
	{
	}
	public BookShop(String name) 
	{
		this.name= name;
	}
	public void setName(String name) 
	{
		this.name= name;
	}
	public void setBook(Book b[]) 
	{
		books=b;
	}
	public String getName( ) 
	{
		return name;
	}
	public void showBook()
	{
		int count=books.length;
		for(int i=0;i<books.length;i++)
		{
			if (books[i]!=null)
			{
				books[i].showDetails();
			}
		}
	}
}
  