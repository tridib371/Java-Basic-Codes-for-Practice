class Main
{
	public static void main(String args[])
	{
		BookShop bs=new BookShop("--------My Store--------");
		
		Book b1 =new Book("123-AA","JAVA-1","Maahi",120.00,400);
		Book b2 =new Book("124-BB","JAVA-2","Maahi",150.00,500);
		Book b3 =new Book("125-CC","JAVA-3","Maahi",200.00,600);

		b1.addQuantity(200);
		b2.addQuantity(200);
		b3.addQuantity(200);
		b1.sellQuantity(122);
		b2.sellQuantity(189);
		b3.sellQuantity(100);
		Book b[]=new Book[10];
		b[0]=b1;
		b[1]=b2;
		b[2]=b3;
		
		bs.setBook(b);		
		System.out.println(bs.getName());
		bs.showBook();
	}
}