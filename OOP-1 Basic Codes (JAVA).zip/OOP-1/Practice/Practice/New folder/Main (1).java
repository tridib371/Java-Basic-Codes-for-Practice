public class Main
{
	public static void main(String args[])
	{
		Account a1=new Account("Formal NUR",1000.000,22464381);
		a1.deposit(500.00);
		a1.withdraw(250.00);
		//Account a2=new Account();
		a1.showProductInfo(a1);
		Account a2=new Account("MAIYYA PAGOL TAUHID",100.000,22464381);
		a2.deposit(700);
		a2.withdraw(200);
		a2.showProductInfo(a1);
	}
}
		
	