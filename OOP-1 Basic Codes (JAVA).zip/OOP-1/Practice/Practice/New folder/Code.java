import java.lang.*;
public class Code
{
private int age;
private double point;
private String name;
public Code()
{
	
}
public Code(int a, double p, String n)
{
	age=a;
	point=p;
	name=n;
}
public void diplayInfo()
{
	System.out.println("Your Age Is  : "+age);
	System.out.println("Your Point Is: "+point);
	System.out.println("Your Name Is : "+name);
}

}