public class Main {

	public static void main(String[] args) {

		Account a1 = new Account("Mahi", 111, 500.0);
		Account a2 = new Account();

		a2.setAccountName("abc");
		a2.setAccountNo(222);
		a2.setBalance(1500.0);

		System.out.println("a1");
		System.out.println("----------------");
		a1.show();
		
		System.out.println();
		System.out.println("a2");
		System.out.println("----------------");
		a2.show();

		System.out.println();
		System.out.println("Adding 500/-");
		System.out.println("----------------");
		a1.addBalance(500.0);
		a1.show();

		System.out.println();
		System.out.println("Withdrawing 700/-");
		System.out.println("----------------");
		a1.withdrawBalance(700.0);
		a1.show();		

		System.out.println();
		System.out.println("Transfer 250/- to account no 222");
		System.out.println("----------------");
		a1.transfer(a2, 250.0);
		a1.show();		
			
		System.out.println();
		System.out.println("Receive 250/- from account no 111");
		System.out.println("----------------");
		a2.show();
	}
}