import java.lang.*;
public class Human
{
public int id;
public String name;
public double cgpa;
public int arr[]=arr[4];
public Human()
{

}
public Human(int i,String n,double cg)
{
	id=i;
	name=name;
	cgpa=cg;
}
public void setid(int i)
{
	id=i;
}
public int getid()
{
	return id;
}public void setname(String n)
{
	name=n;
}
public String getname()
{
	return name;
}public void setcgpa(double cg)
{
	cgpa=cg;
}
public double getcgpa()
{
	return cgpa;
}
public void displayInfo()
{
	System.out.println("Human ID: "+id);
	System.out.println("Human ID: "+name);
	System.out.println("Human ID: "+cgpa);
}
public static void main(String args[])
{
	Human h1=new Human();
	h1.setid(123);
	h1.setname("Maahi");
	h1.setcgpa(4.12);
	System.out.println(h1.getid());
	System.out.println(h1.getname());
	h1.displayInfo();
	System.out.println(h1.getcgpa());
}
}