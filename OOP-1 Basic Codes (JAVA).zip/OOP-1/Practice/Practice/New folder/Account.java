import java.lang.*;

public class Account {

	private String accountName;
	private int accountNo;
	private double balance;
	//public static double limit = 1000.0;

	public Account() {}

	public Account(String accountName, int accountNo, double balance) {
		this.accountName = accountName;
		this.accountNo = accountNo;
		this.balance = balance;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public void show() {
		System.out.println("account name = " + accountName);
		System.out.println("account no = " + accountNo);
		System.out.println("balance = " + balance);
	}

	public void addBalance(double amount) {
		this.balance += amount;
	}

	public boolean withdrawBalance(double amount) {
		if (amount < this.balance) {
			this.balance -= amount;
			return true;
		}
		return false;
	}

	public void transfer(Account to, double amount) {
		//if (amount < Account.limit) {
			boolean res = withdrawBalance(amount);
			if (res) {
				to.addBalance(amount);
			}
			else {
				System.out.println("***Transaction failed due to insufficient balance.***");
			}
		/*}
		else {
			System.out.println("***Limit exceeded***");
		}
	}*/
}
}