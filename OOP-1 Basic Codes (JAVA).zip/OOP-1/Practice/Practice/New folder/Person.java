import java.lang.*;
public class Person
{
	{
	public int age;
	public String name;
	public double cgpa;
	public Person()
	{
		
	}
	/*public Person(int a,String n,double cg)
	{
		
		name=n;
		age=a;
		cgpa=cg;
	}*/

	public void setname(String n)
	{
		name=n;
	}
	public String getname()
	{
		return name;
	}
	public void setage(int a)
	{
		age=a;
	}
	public int getage()
	{
		return age;
	}
	public void setcgpa(int cg)
	{
		cgpa=cg;
	}
	public int getcgpa()
	{
		return cgpa;
	}
		/*public void display()
	{
		System.out.println("---------------------------------");
		System.out.println("Student Name :"+name);
		System.out.println("Studen age   :"+age);
		System.out.println("Studen CGPA  :"+cgpa);
        System.out.println("---------------------------------");
	}*/
	
	public static void main(String args[])
	{
		
		Person p1=new Person();
		p1.setname("Mahmudus Sami Maahi");
		p1.setage(22);
		p1.setcgpa(3.90);
		System.out.println(p1.getname());
		System.out.println(p1.getage());
		System.out.println(p1.getcgpa());
	}
}