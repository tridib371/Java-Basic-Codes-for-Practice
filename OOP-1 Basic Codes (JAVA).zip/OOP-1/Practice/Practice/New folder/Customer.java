public class Customer
{
	int id;
	String name;
	SavingsAccount sa;
	FixedAccount fa;
	public Customer()
	{
		
	}
	public Customer(int id , String name , SavingAccount sa, FixedAccount fa)
	{
		this.id=id;
		this.name=name;
		this.SavingAccount=sa;
		this.FixedAccount=fa;
	}
	public void setname(int name)
	{
		this.name=name;
	}
	public void setid(int id)
	{
		this.id=id;
	}
	public void setSavingsAccount(SavingsAccount sa)
	{
		this.sa=sa;
	}
	public void setFixedAccount(FixedAccount fa)
	{
		this.fa=fa;
	}
	public String getname()
	{
		return name;
	}
	public int getid()
	{
		return id;
	}
	public SavingsAccount getSavingsAccount()
	{
		return SavingsAccount;
	}
	public FixedAccount getFixedAccount()
	{
		return FixedAccount;
	}
	
}