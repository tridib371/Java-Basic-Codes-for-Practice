public class Account
{
	private String accountName;
	private double balance;
	private int accountNumber;
	Account()
	{
	}
	Account(String accountName,double balance,int accountNumber)
	{
		this.accountName=accountName;
		this.balance=balance;
		this.accountNumber=accountNumber;
	}
	public void setAccountName(String accountName)
	{
		this.accountName=accountName;
	}
	public void setBalance(double balance)
	{
		this.balance=balance;
	}
	public void setAccountNumber(int accountNumber)
	{
		this.accountNumber=accountNumber;
	}
	public String getAccounName()
	{
		return accountName;
	}                                                                                             
	public double getBalance()
	{
		return balance;
	}
	public int getAccountNumber()
	{
		return accountNumber;
	}
	public void deposit(double amount)
	{
		balance+=amount;
	}
	public void withdraw(double amount)
	{
		balance-=amount;
	}
	public void showProductInfo(Account a)
	{
		System.out.println("Account Name is    : "+accountName);
		System.out.println("Account Balance is : "+balance);
		System.out.println("Account Number is  : "+accountNumber);
		//System.out.println("After Deposit      : "+a.deposit(amount));
		//System.out.println("After WithDraw     : "+a.withdraw(amount));
	}
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	
