import java.lang.*;
public class Student
{
	{
	private int id;
	private String name;
	private double cgpa;
	public Student()
	{
		
	}
	public Student(int i,String n, double cg)
	{
		id=i;
		name=n;
		cgpa=cg;
	}
	public void display()
	{
		System.out.println("---------------------------------");
		System.out.println("Student Name  :"+name);
		System.out.println("Studen ID     :"+id);
		System.out.println("Studen CGPA   :"+cgpa);
        System.out.println("---------------------------------");
	}
	public void setname(String n)
	{
		name=n;
	}
	public String getname()
	{
		return name;
	}
	public void setid(int i)
	{
		id=i;
	}
	public int getid()
	{
		return id;
	}
	public void setcgpa(double cg)
	{
		cgpa=cg;
	}
	public double getcgpa()
	{
		return cgpa;
	}
	public static void main(String args[])
	{
		Student s=new Student();
		s.setname("Mahmudus Smai Maahi");
		s.setid(22464461);
		s.setcgpa(3.90);
		System.out.println(s.getname());
		System.out.println(s.getid());
		System.out.println(s.getcgpa());
	}
}