public class ScientificCalculator extends BasicCalculator
{
  ScientificCalculator( )
  {
	  
  }
  ScientificCalculator (double v1, double v2)
  {
	  super(v1,v2);
  }
  public double toThePow()
  {
	  double e= Math.pow(value1,value2);
	  return e;
  }
}