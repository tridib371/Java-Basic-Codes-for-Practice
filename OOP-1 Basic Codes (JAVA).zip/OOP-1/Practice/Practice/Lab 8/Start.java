public class Start
{
	public static void main(String args[])
	{
		ScientificCalculator b= new ScientificCalculator(3,6);
		
		System.out.println("ADD      :"  +b.add());
		System.out.println("Multiply :"  +b.subtract());
		System.out.println("Divide   :"  +b.multiply());
		System.out.println("Divide   :"  +b.divide());
		System.out.println("POwer    :"  +b.toThePow());
	}
}