public class BasicCalculator implements Calculation
{
protected double value1;
protected double value2;
BasicCalculator( )
{
	
}
BasicCalculator(double v1, double v2)
{
	value1=v1;
	value2=v2;
}
public void setValue1(double v1)
{
	value1=v1;
}
public void setValue2(double v2)
{
	value2=v2;
}
public double getValue1( )
{
	return value1;
}
public double getValue2( )
{
	return value2;
}
public double add()
{
	return value1+value2;
}
public double subtract()
{
	return value1-value2;
}
public double multiply()
{
	return value1*value2;
}
public double divide()
{
	return value1/value2;
}

}