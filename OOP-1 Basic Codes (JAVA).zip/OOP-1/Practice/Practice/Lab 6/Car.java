public class Car
{
	String name;
	String modelNumber;
	public void setname(String name)
	{
		this.name=name;
	
	}
	public void setmodelNumber(String modelNumber)
	{
		this.modelNumber=modelNumber;
	}
	public String getname()
	{
		return name;
	}
	public String getmodelNumber()
	{
		return modelNumber;
	}
	public Car(String name, String modelNumber)
	{
		System.out.println(">>>>>>>-----Constructor overLoading------<<<<<<<");
		this.name=name;
		this.modelNumber=modelNumber;
	}
	public Car(String modelNumber)
	{
		System.out.println(">>>>>>>-----Constructor overLoading------<<<<<<<");
		this.modelNumber=modelNumber;
	}
	public Car()
	{
		System.out.println(">>>>>>>-----Constructor overLoading------<<<<<<<");
	}
	public void showInfo()
	{
		System.out.println("Name :"+this.name);
		System.out.println("Model Number :"+this.modelNumber);
	}
	
}