public class Driver
{
	String name;
	double dnumber;
	public void setname(String name)
	{
		this.name=name;
	}
	public void setdnumber(double dnumber)
	{
		this.dnumber=dnumber;
	}
	public String getname()
	{
		return name;
	}
	public double getdnumber()
	{
		return dnumber;
	}
	public Driver(String name, double dnumber)
	{
		this.name=name;
		this.dnumber=dnumber;
	}
	public void showInfo()
	{
		System.out.println("Name :"+this.name);
		System.out.println("Driver Number :"+this.dnumber);
	}
}