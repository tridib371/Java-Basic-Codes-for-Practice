public class Main
{
	public static void main(String args[])
	{
		Car c=new Car("T-20","1223-AA-12-DF");
		c.showInfo();
		Car c1=new Car("T-20","1223-AA-12-DF");
		c1.showInfo();
		Car c2=new Car("T-20","1223-AA-12-DF");
		c2.showInfo();
		Driver d=new Driver("Tauhid",199344);
		d.showInfo();
		Driver d1=new Driver("Tauhid",199344);
		d1.showInfo();
		Driver d2=new Driver("Tauhid",199344);
		d2.showInfo();
	}
}