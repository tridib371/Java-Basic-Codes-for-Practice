public class MainBooks{

    public static void main ( String args [] ){

        StoryBooks b1 = new StoryBooks();

        b1.setIsbn(" 12341 ");
        b1.setBookTitle(" Secret Garden ");
        b1.setAuthorName(" Fahim ");
        b1.setPrice(1500);
        b1.setAvailableQuantity(5);
        b1.setCategory(" Romantic Drama ");

        System.out.println("Isbn               : "+b1.getIsbn());
        System.out.println("Book Title         : "+b1.getBookTitle());
        System.out.println("Author Name        : "+b1.getAuthorName());
        System.out.println("Price              : "+b1.getPrice());
        System.out.println("Available Quantity : "+b1.getAvailableQuantity());
        System.out.println("Category           : "+b1.getCategory());
        System.out.println(" ");

        StoryBooks b2 = new StoryBooks( "54231", " Your Name ", " Faiaz ", 1200, 10, " Romantic Drama " );



        TextBooks b3 = new TextBooks();

        b3.setIsbn(" 2356-6543 ");
        b3.setBookTitle(" Muhamud : The man and Prophet ");
        b3.setAuthorName(" Adil Salahi ");
        b3.setPrice(500);
        b3.setAvailableQuantity(7);
        b3.setStandard(11);

        System.out.println("Isbn               : "+b3.getIsbn());
        System.out.println("Book Title         : "+b3.getBookTitle());
        System.out.println("Author Name        : "+b3.getAuthorName());
        System.out.println("Price              : "+b3.getPrice());
        System.out.println("Available Quantity : "+b3.getAvailableQuantity());
        System.out.println("Standard           : "+b3.getStandard());
        System.out.println(" ");

        TextBooks b4 = new TextBooks( "9999-6543", " Shrikanto ", " Sharatchandro chsatterjee ", 1200, 10, 12 );

        System.out.println("Story Book : ");
		b1.showDetails();
        System.out.println(" ");
		b2.showDetails();
		System.out.println(" ");
		
		System.out.println("Text Book : ");
		b3.showDetails();
        System.out.println(" ");
		b4.showDetails();

    }

}