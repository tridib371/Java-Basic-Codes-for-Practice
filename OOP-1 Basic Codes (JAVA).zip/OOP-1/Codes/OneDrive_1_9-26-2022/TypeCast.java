import java.lang.*;

public class TypeCast
{
	public static void main(String[] args)
	{
		int a = 10;
		double d = 0.0;
		
		d = a;// implicit typecasting
		System.out.println("int a: "+a);
		System.out.println("double d: "+d);
		
		int a1 = 0;
		double d1 = 5.5;
		
		a1 = (int) d1;// explicit typecasting
		System.out.println("int a: "+a1);
		System.out.println("double d: "+d1);
	}
}