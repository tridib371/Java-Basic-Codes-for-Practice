import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Account a1 = new Account();
		a1.setAccNo(109);
		a1.setBalance(500);
		
		a1.display();
		
		Account a2 = new Account(101, 1500);
		a2.display();
		
		if(a1.getBalace() < a2.getBalace())
		{
			System.out.println("A2 BOROLOK");
		}
		else
		{
			System.out.println("A1 BOROLOK");
		}
	}
}