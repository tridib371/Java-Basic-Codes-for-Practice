import java.lang.*;

public class Account
{
	private int accNo;
	private double balance;
	
	public Account()
	{
		System.out.println("Empty Cons");
	}
	
	public Account(int accNo, double balance)
	{
		System.out.println("Parameterized cons");
		this.accNo = accNo;
		this.balance = balance;
		
	}
	public void setAccNo(int accNo)
	{
		this.accNo = accNo;
	}
	public void setBalance(double balance)
	{
		this.balance = balance;
	}
	
	public int getAccNo()
	{
		return accNo;
	}
	public double getBalace()
	{
		return balance;
	}
	
	public void display()
	{
		System.out.println("AccNo: "+accNo);
		System.out.println("Balance: "+balance);
	}
	
	
}