import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Account ami = new Account(123, 1500);
		Account bondhu = new Account(456, 200);
		ami.display();
		
		ami.withdraw(10000);
		ami.deposit(2000);
		ami.display();
		
		ami.transfer(bondhu, 500);
		bondhu.display();
		ami.display();
		
	}
}