public class MainBooks {
    public static void main(String [] args) {

        int i, k=1; 
        Double a, b,Sum;
        Books B1 [] = new Books [5];

        B1[0]=new Books( " 2356-6543 ", " Muhamud : The man and Prophet ", " Adil Salahi ", 500, 10 );
        B1[1]=new Books( " 1566-6543 ", " Holud Himu Kaalo RBR ", " Humayun Ahmed ", 100, 30);
        B1[2]=new Books( " 9999-6543 ", " Shrikanto ", " Sharatchandro chsatterjee ", 300, 15);
        B1[3]=new Books( " 2356-6545 ", " Figh of Priorities ", " Yusuf Al QaradaWi ", 200, 5);
        B1[4]=new Books( " 2356-6743 ", " Destiny Disrupted ", " Tamim ", 300, 3);
        
       
        for( i=0; i<5; i=i+1 )

            if( B1[i].getPrice()>200 ){

                System.out.println(" Book " +k+ ": "+B1[i].getAuthorName()+", Book index : "+i);
                k=k+1;
            }
         a = B1[1].getPrice()*3;
         b = B1[2].getPrice()*4;
         Sum = a+b;
         System.out.println(" ");
         System.out.println(" Total Price of 3 Copies Holud Himu Kaalo RAB : "+B1[1].getPrice()*3);
         System.out.println(" Total Price of 4 Copies of Srikanto          : "+B1[2].getPrice()*4);
         System.out.println(" Total Amount of 3 Copies Holud Himu Kaalo RAB and 4 Copies of Srikanto is : "+Sum);
        
    }    
    
}