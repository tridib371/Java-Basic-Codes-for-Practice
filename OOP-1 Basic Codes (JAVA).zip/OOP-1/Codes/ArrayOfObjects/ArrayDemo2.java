import java.lang.*;
public class ArrayDemo2
{
	public static void main(String[] args)
	{
		
		//2d array
		int arr5[][] = new int[2][2];
		//row - 0,1; column = 0,1
		arr5[0][0] = 10;
		arr5[0][1] = 20;
		arr5[1][0] = 30;
		arr5[1][1] = 40;
		
		for(int i = 0; i<2; i++)
		{
			for(int m = 0; m<2; m++)
			{
				System.out.println("arr5["+i+"]["+m+"]: "+arr5[i][m]);
			}
		}
		int check1 = 0;
		for(int i = 0; i<2; i++)
		{
			for(int m = 0; m<2; m++)
			{
				if(arr5[i][m]==30)
				{
					check1 = 1;
				}
				
			}
		}
		if(check1 == 1)
		{
			System.out.println("Pawa geche");
		}
		else
		{
			System.out.println("Nai bhai!");
		}
		
		int arr6[][];
		int row = arr5[0][1]/arr5[0][0];
		int column = arr5[0][1]/arr5[0][0];
		arr6 = new int[row][column];
		
		int arr7[][] = new int[][]{{10, 20, 50},{30, 40, 60}};
		int arr8[][] = {{10, 20, 50},{30, 40, 60}};
	}
}