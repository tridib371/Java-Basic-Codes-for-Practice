import java.lang.*;

public class ArrayDemo
{
	public static void main(String[] args)
	{
		/*int arr1[] = new int[3];
		arr1[0] = 10;
		arr1[1] = 20;
		arr1[2] = 30;
		
		for(int i = 0; i<arr1.length; i++)
		{
			System.out.println("arr1["+i+"] :"+arr1[i]);
		}
		int k=0;
		while(k<arr1.length)
		{
			System.out.println(arr1[k]);
			k++;
		}
		int j = 0;
		do
		{
			System.out.println(arr1[j]);
			j++;
		}while(j<arr1.length);
		int check=0;
		for(int i=0; i<arr1.length;i++)
		{
			if(arr1[i]==20)
			{
				arr1[i] = 0;
				check = 1;
			}
		}
		if(check ==1 )
		{
			System.out.println("Found and deleted!");
		}
		else
		{
			System.out.println("Not found!");
		}
		for(int i = 0; i<arr1.length; i++)
		{
			System.out.println("arr1["+i+"] :"+arr1[i]);
		}
		
		//2nd approach
		int arr2[];
		int size = arr1[0]/5;
		arr2 = new int[size];
		arr2[0] = 100;
		arr2[1] = 200;
		for(int i = 0; i<arr2.length; i++)
		{
			System.out.println("arr2["+i+"] :"+arr2[i]);
		}
		
		//3rd approach
		int []arr3 = new int[]{300, 400}; 
		for(int i = 0; i<arr3.length; i++)
		{
			System.out.println("arr3["+i+"] :"+arr3[i]);
		}
		arr3[1] = 500;
		for(int i = 0; i<arr3.length; i++)
		{
			System.out.println("arr3["+i+"] :"+arr3[i]);
		}
		//4th approach
		int arr4[] = {1000, 2000};
		for(int i = 0; i<arr4.length; i++)
		{
			System.out.println("arr4["+i+"] :"+arr4[i]);
		}*/
		
		//2d array
		int arr5[][] = new int[2][2];
		//row - 0,1; column = 0,1
		arr5[0][0] = 10;
		arr5[0][1] = 20;
		arr5[1][0] = 30;
		arr5[1][1] = 40;
		
		for(int i = 0; i<2; i++)
		{
			for(int m = 0; m<2; m++)
			{
				System.out.println("arr5["+i+"]["+m+"]: "+arr5[i][m]);
			}
		}
		int check1 = 0;
		for(int i = 0; i<2; i++)
		{
			for(int m = 0; m<2; m++)
			{
				if(arr5[i][m]==30)
				{
					check1 = 1;
				}
				
			}
		}
		if(check1 == 1)
		{
			System.out.println("Pawa geche");
		}
		else
		{
			System.out.println("Nai bhai!");
		}
		
		int arr6[][];
		int row = arr5[0][1]/arr5[0][0];
		int column = arr5[0][1]/arr5[0][0];
		arr6 = new int[row][column];
		
		int arr7[][] = new int[][]{{10, 20, 50},{30, 40, 60}};
		int arr8[][] = {{10, 20, 50},{30, 40, 60}};
	}
}