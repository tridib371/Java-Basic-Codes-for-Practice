import java.lang.*;

public class Student
{
	private int id;
	public Student()
	{
		
	}
	public Student(int id)
	{
		this.id = id;
	}
	public void setID(int id)
	{
		this.id = id;
	}
	public int getID()
	{
		return id;
	}
	public void display()
	{
		System.out.println("ID: "+id);
	}
	
}