import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Student s1 = new Student();
		Student s3 = new Student();
		s1.setID(765);
		//System.out.println("s1.ID: "+s1.getID());
		
		
		Student s2 = new Student(123);
		//System.out.println("s2.ID: "+s2.getID());
		
		//s1.display();
		//s2.display();
		
		Student students [] = new Student[]{s1,s2,s3};
		//students[0] = s1;		
		//students[1] = s2;	
		
		students[2].setID(999);

		for(int i=0; i<students.length; i++)
		{
			//students[i].display();
			System.out.println("students["+i+"].id: "+students[i].getID());
		}
		//search
		int x=0;
		for(int i=0; i<students.length; i++)
		{
			if(students[i].getID() == 999)
			{
				x = 1;
			}
		}
		if(x==1)
		{
			System.out.println("Found!");
		}
		else
		{
			System.out.println("Not Found!");
		}
		
		//delete
		int y = 0;
		for(int i=0; i<students.length; i++)
		{
			if(students[i] == s2)
			{
				students[i] = null;
				y = 1;
			}
		}
		if(y==1)
		{
			System.out.println("Found and deleted!");
		}
		else
		{
			System.out.println("Not Found!");
		}
		//print after deletion
		for(int i=0; i<students.length; i++)
		{
			if(students[i]!=null)
			{
				//students[i].display();
			System.out.println("students["+i+"].id: "+students[i].getID());
			}
			else
			{
				System.out.println("Null at: students["+i+"]");
			}
		}
		
			
		
	}
	
}