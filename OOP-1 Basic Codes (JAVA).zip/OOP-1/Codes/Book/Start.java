import java.util.Scanner;

public class Start
{
	public static void main (String[]args)
	{
		Bookshop b1=new Bookshop ("BookStore");
		
		TextBook tb1= new TextBook("1st Release","James Harden-1","Tony Zaret-1",100,10,1);
		TextBook tb2= new TextBook("2nd Release","James Harden-2","Tony Zaret-2",200,20,2);
		TextBook tb3= new TextBook("3rd Release","James Harden-3","Tony Zaret-3",300,30,3);
		TextBook tb4= new TextBook("4th Release","James Harden-4","Tony Zaret-4",400,40,4);
		TextBook tb5= new TextBook("5th Release","James Harden-5","Tony Zaret-5",500,50,5);
		if(b1.insertTextBook(tb1))
		{
			System.out.println("TextBOOK 1 inserted");
		}
		else
		{
			System.out.println("TextBOOKs overflow");
		}
		b1.insertTextBook(tb2);
		b1.insertTextBook(tb3);
		b1.insertTextBook(tb4);
		b1.insertTextBook(tb5);
		
		
		StoryBook sb1= new StoryBook("First","Huckleberry Finn-1","Charles Dickens-1",100,10,"Adventure-1");
		StoryBook sb2= new StoryBook("Secound","Huckleberry Finn-2","Charles Dickens-2",200,20,"Adventure-2");
		StoryBook sb3= new StoryBook("Third","Huckleberry Finn-3","Charles Dickens-3",300,30,"Adventure-3");
		StoryBook sb4= new StoryBook("Forth","Huckleberry Finn-4","Charles Dickens=4",400,40,"Adventure-4");
		StoryBook sb5= new StoryBook("Fifth","Huckleberry Finn-5","Charles Dickens-5",500,50,"Adventure-5");
		b1.insertStoryBook(sb1);
		b1.insertStoryBook(sb2);
		b1.insertStoryBook(sb3);
		b1.insertStoryBook(sb4);
		b1.insertStoryBook(sb5);
		b1.showAllTextBooks();
		b1.showAllStoryBooks();
		System.out.println("\nAfte Removing Story Book 3\n");
		if(b1.removeStoryBook(sb3))
		{
			System.out.println("Removed");
		}
		else
		{
			System.out.println("No match found");
		}
		b1.showAllStoryBooks();
		System.out.println("\nSerching Text Book 2\n");
		b1.searchTextBook("2nd Release").showDetails();
		
		
		
		Scanner sc = new Scanner(System.in);
        //String str;

        System.out.println("Enter a string: ");					        
		String str = sc.nextLine();
		System.out.println("Enter a string: ");
		String s=sc.nextLine();

        System.out.println("You have entered: " + str);
		System.out.println("You have entered: " + s);
	}
}
