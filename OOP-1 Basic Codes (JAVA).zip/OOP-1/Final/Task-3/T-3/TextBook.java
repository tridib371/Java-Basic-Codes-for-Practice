import java.lang.*;
public class TextBook extends Book

{
	
	private int standard;
	
	public TextBook()
	{
		
	}
	public TextBook(String isbn, String bookTitle, String authorName, double price, int availableQuantity, int standard)
	{
		super(isbn, bookTitle, authorName, price, availableQuantity);
		this.standard=standard;
	}
	
	public void setStandard(int standard)
	{
		this.standard=standard;
	}
	public int getStandard()
	{
		return standard;
	}
	public void showDetails()
	{
		
		System.out.println("Book ISBN          : "+isbn);
		System.out.println("Title              : "+bookTitle);
		System.out.println("Author Name        : "+authorName);
		System.out.println("Price              : "+price);
		System.out.println("Available Quantity : "+availableQuantity);
		System.out.println("Book Standard      : "+standard);
	}
}