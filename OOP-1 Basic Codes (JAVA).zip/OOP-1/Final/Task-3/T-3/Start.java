import java.lang.*;
public class Start

{
	public static void main(String[] args)
	
	{
 		
		Book tb1 = new TextBook("33-756-6", " In Search of Lost Time", "Marcel Proust", 600, 90, 8);
		Book tb2 = new TextBook("14-543-7", " Ulysses", "James Joyce", 600, 70, 8);
		Book tb3 = new TextBook("32-463-2", "Don Quixote", "Miguel de Cervantes", 700, 30, 4);
		Book tb4 = new TextBook("32-768-8", "One Hundred Years of Solitude ", "Gabriel Garcia Marquez", 100, 2, 3);
		Book tb5 = new TextBook("14-449-7", " The Great Gatsby", "F. Scott Fitzgerald", 400, 60, 7);
		
		
		Book sb1 = new StoryBook("0-7645-787-44", "Moby Dick", "Herman Melville", 500, 40, "Advanture");
		Book sb2 = new StoryBook("1-6644-786-45", "War and Peace", "Leo Tolstoy", 700, 90, "Western");
		Book sb3 = new StoryBook("3-5643-785-46", " Hamlet", "William Shakespeare", 600, 70, "Historical");
		Book sb4 = new StoryBook("4-4642-784-47", "The Odyssey", "Homer", 300, 60, "Thriller");
		Book sb5 = new StoryBook("5-3641-783-48", " Madame Bovary", " Gustave Flaubert", 400, 50, "Fantasy");
		
		
		System.out.println("\n");
		System.out.println("=====********======*********========********=========");
		BookShop bs = new BookShop("BOOK STORE");
		bs.setName("                          BOOK STORE");
		System.out.println(bs.getName());
		System.out.println("=====********======*********========********=========");
		
		
		System.out.println("\n");
		
		
		System.out.println("*******************************");
		System.out.println("           Books");
		System.out.println(" *******************************");
		System.out.println("\n");
		System.out.println(" *******************************");
		System.out.println("         Insert Book");
		System.out.println("*******************************");
		bs.insertBook(tb1);
		bs.insertBook(tb2);
		bs.insertBook(tb3);
		bs.insertBook(tb4);
		bs.insertBook(tb5);
		
		bs.insertBook(sb1);
		bs.insertBook(sb2);
		bs.insertBook(sb3);
		bs.insertBook(sb4);
		bs.insertBook(sb5);
		
		
		System.out.println("\n");
		
		
		System.out.println("   *******************************");
		System.out.println("          Remove Book");
		System.out.println("   *******************************");
		bs.removeBook(tb2);
		
		
		System.out.println("\n");
		
		
		System.out.println("   *******************************");
		System.out.println("          Search Book");
		System.out.println("   *******************************");
		bs.searchBook("3334-76645-6");
		
		
		System.out.println("\n");
		
		
		System.out.println("   *******************************");
		System.out.println("         Show All Books");
		System.out.println("   *******************************");
		bs.showAllBooks();
		
	}
}