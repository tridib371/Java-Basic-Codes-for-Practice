public interface BookShopOperations
{
	
	void insertBook(Book b);
	void removeBook(Book b);
	void showAllBooks();
	void searchBook(String isbn);
}