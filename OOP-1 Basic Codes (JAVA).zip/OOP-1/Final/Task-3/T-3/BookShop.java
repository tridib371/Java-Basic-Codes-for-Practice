import java.lang.*;
public class BookShop implements BookShopOperations

{
	private String name;
	private Book listOfBooks[] = new Book[100];
	
	public BookShop()
	
	{
		System.out.println("Empty Book Shop");
	}
	
	public BookShop(String name)
	
	{
		this.name=name;
	}
	
	public void setName(String name)
	
	{
		this.name=name;
	}
	
	public String getName()
	
	{
		return name;
	}
	
	
	public void insertBook(Book b)
	
	{
		int check=0;
		for(int i=0; i<listOfBooks.length; i++)
		{
			if(listOfBooks[i]==null)
			{
				listOfBooks[i]=b;
				check=1;
				break;
			}
		}
		if(check==1)
		{
			System.out.println("Book inserted successfully");
		}
		else
		{
			System.out.println("Book not inserted");
		}
	}
	
	public void removeBook(Book b)
	
	{
		int check=0;
		for(int i=0; i<listOfBooks.length; i++)
			
		{
			if(listOfBooks[i]==b)
				
			{
				listOfBooks[i]=null;
				check=1;
				break;
			}
		}
		
		if(check==1)
		{
			System.out.println("Book removed successfully");
		}
	}
	
	public void showAllBooks()
	
	{
		
		for(int i=0; i<listOfBooks.length; i++)
			
		{
			if(listOfBooks[i]!=null)
				
			{
			listOfBooks[i].showDetails();
			System.out.println(" ");
			
			}
			
		}
	}
	
	public void searchBook(String isbn)
	
	{
		int check=0;
		
		for(int i=0; i<listOfBooks.length; i++)
			
		{
			if(listOfBooks[i]!=null){
			if(listOfBooks[i].getIsbn()==isbn)
				
			{
				check=1;
				break;
			}
			
			}
			
		}
		
		if(check==1)
		{
			System.out.println("Book found");
		}
		else
		{
			System.out.println("Book not found");
		}
	}

}