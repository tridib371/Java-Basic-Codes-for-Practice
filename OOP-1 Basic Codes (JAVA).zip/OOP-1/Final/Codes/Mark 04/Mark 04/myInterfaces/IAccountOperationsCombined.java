package myInterfaces;
public interface IAccountOperationsCombined extends IAccountOperation, IAccountOperationAdvance{

}