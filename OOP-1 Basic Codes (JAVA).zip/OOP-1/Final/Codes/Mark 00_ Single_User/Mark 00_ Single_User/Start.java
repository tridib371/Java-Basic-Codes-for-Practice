import javax.swing.*;  
import java.awt.event.*; 
public class Start{
	
	public static void main(String[] args) {  
	 
		new Login();
	} 
}