import java.lang.*;

public abstract class Account
{
	protected int accNo;
	protected double balance;
	
	public Account(int accNo, double balance)
	{
		this.accNo = accNo;
		this.balance = balance;
	}
	public abstract void display();
	/*{
		System.out.println("ACC NO: "+accNo);
		System.out.println("ACC Balance: "+balance);
	}*/
	
	public void withdraw(double amount)
	{
		if(balance>amount && amount >0)
		{
			balance = balance-amount;
		}
		else
		{
			System.out.println("Transaction failed!");
		}
	}
}