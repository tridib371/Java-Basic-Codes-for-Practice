import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Account ami = new Account(123, 1500);
		Account shamim = new Account(456, 200);
		Account nahid = new Account(234, 1000);
		
		Customer c1 = new Customer("C-01", ami);
		Customer c2 = new Customer("C-02", shamim);
		Customer c3 = new Customer("C-03", nahid);
		Customer c4 = new Customer("C-04", ami);
		Customer c5 = new Customer("C-05", shamim);
		//c2.showDetails();
		
		System.out.println("**********************************");
		
		c1.performDeposit(400);
		c1.performWithdraw(100);
		c2.performDeposit(400);
		c2.performWithdraw(100);
		c3.performDeposit(400);
		c3.performWithdraw(400);
		
		//ami = 1800
		//shamim = 500
		//nahid = 1000
		
		c1.performTransfer(shamim, 200);
		
		//c1 = this(ami)
		//acc = shamim
		
		//acc(shamim) balance = balance(500) + 200 = 700
		//this(ami) balance = balance(1800) - 200 = 1600
		
		c2.performTransfer(ami, 300);
		
		//c2 = this(shamim)
		//acc = ami
		
		//acc(ami) balance = balance(1600) + 300 = 1900
		//this(shamim) balance = balance(700) - 300 = 400
		
		c3.performTransfer(ami, 300);
		
		//c3 = this(nahid)
		//acc = ami
		
		//acc(ami) balance = balance(1900) + 300 = 2200
		//this(nahid) balance = balance(1000) - 300 = 700
		
		c4.performTransfer(shamim, 300);
		
		//c4 = this(ami)
		//acc = shamim
		
		//acc(shamim) balance = balance(400) + 300 = 700
		//this(ami) balance = balance(2200) - 300 = 1900
		
		c5.performTransfer(ami, 400);
		
		//c5 = this(shamim)
		//acc = ami
		
		//acc(ami) balance = balance(1900) + 400 = 2300
		//this(shamim) balance = balance(700) - 400 = 300
		
		//c2.showDetails();
		
		System.out.println("Ami : "+ ami.getBalance());
		System.out.println("Shamim : "+ shamim.getBalance());
		System.out.println("Nahid : "+ nahid.getBalance());		
		
	}
}