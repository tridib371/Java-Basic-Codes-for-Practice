import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Account ami = new Account(123, 1500);
		Account bondhu = new Account(456, 200);
		
		Customer c1 = new Customer("C-01", ami);
		c1.showDetails();
		
		c1.performDeposit(400);
		c1.performWithdraw(100);
		c1.performTransfer(bondhu, 400);
		
		c1.showDetails();
		
		
		
	}
}