import java.lang.*;

public class Customer
{
	private String cID;
	private Account acc;
	
	public Customer()
	{
		System.out.println("Empty Customer");
	}
	public Customer(String cID, Account acc)
	{
		System.out.println("Parameterized Customer");
		this.cID = cID;
		this.acc = acc;
	}
	public void setCid(String cID)
	{
		this.cID = cID;
	}
	public void setAcc(Account acc)
	{
		this.acc = acc;
	}
	public String getCid()
	{
		return cID;
	}
	public Account getAcc()
	{
		return acc;
	}
	
	public void performDeposit(double amount)
	{
		acc.deposit(amount);
	}
	public void performWithdraw(double amount)
	{
		acc.withdraw(amount);
	}
	public void performTransfer(Account a, double amount)
	{
		acc.transfer(a, amount);
	}
	public void showDetails()
	{
		System.out.println("Customer ID: "+ cID);
		acc.display();
	}
	
	
}