import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Account a1 = new Account(123, 1500);
		Account a2 = new Account(456, 200);
		Account a3 = new Account(678, 2200);
		Account a4 = new Account(987, 3200);
		
		Customer c1 = new Customer("John", 45,"C-01", 2);
		c1.display();
		/*Customer c2 = new Customer("C-02", 1);
		/Customer c3 = new Customer("C-03", 1);
		
		c1.addAccount(a1);
		c1.addAccount(a2);
		c1.addAccount(a3);
		
		c1.searchAccount(a2);
		
		c1.removeAccount(a2);
		
		c1.searchAccount(a2);
		
		c1.displayAllAccount();
		
		c1.performDeposit(a1, 500);
		
		c1.displayAllAccount();*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*c1.showDetails();
		
		c1.performDeposit(400);
		c1.performWithdraw(100);
		c1.performTransfer(a2, 400);
		
		c1.showDetails();*/
		
		
		
	}
}