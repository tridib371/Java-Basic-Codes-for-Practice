public class Start
{
    public static void main(String args[])
    {
        StoryBook s1 = new StoryBook("gh", "Applwogy", "Hamz",230,45,"Good");
        StoryBook s2 = new StoryBook("gee", "Appldogy", "Hamz",230,45,"Good");
        StoryBook s3 = new StoryBook("geeh", "Appdlogy", "Hamz",230,45,"Good");
        StoryBook s4 = new StoryBook("gaah", "Applvogy", "Hamz",230,45,"Good");
        StoryBook s5 = new StoryBook("gqqh", "Applogy", "Hamz",230,45,"Good");


        TextBook t1 = new TextBook( " 2356-6543 ", " Muhamud : The man and Prophet ", " Adil Salahi ", 500, 10,111 );
        TextBook t2 = new TextBook( " 1566-6543 ", " Holud Himu Kaalo RBR ", " Humayun Ahmed ", 100, 30,222);
        TextBook t3 = new TextBook( " 9999-6543 ", " Shrikanto ", " Sharatchandro chsatterjee ", 300, 15,333);
        TextBook t4 = new TextBook( " 2356-6545 ", " Figh of Priorities ", " Yusuf Al QaradaWi ", 200, 5,444);
        TextBook t5 = new TextBook( " 2356-6743 ", " Destiny Disrupted ", " Tamim ", 300, 3,555);

        BookShop b = new BookShop("Ratul Modern Book House");

        b.showDetails();

        System.out.println("-----------------------------------------");
        if(b.insertStoryBook(s1))
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        if(b.insertStoryBook(s2) )
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        if(b.insertStoryBook(s3))
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        if(b.insertStoryBook(s4))
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        if(b.insertStoryBook(s5))
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }
        System.out.println("-----------------------------------------");


        System.out.println("-----------------------------------------");
        if(b.insertTextBook(t1))
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        if(b.insertTextBook(t2) )
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        if(b.insertTextBook(t3))
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }
        if(b.insertTextBook(t4) )
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }
        if(b.insertTextBook(t5) )
        {
            System.out.println("Book Insertted");
        }
        else
        {
            System.out.println("Can NOT be Inserted");
        }

        System.out.println("-----------------------------------------");

        b.showDetails();

        System.out.println("-----------------------------------------");
        if(b.removeStoryBook(s1))
        {
            System.out.println("Book Removed");
        }
        else
        {
            System.out.println("Can NOT be Removed");
        }

        if(b.removeTextBook(t3) )
        {
            System.out.println("Book Removed");
        }
        else
        {
            System.out.println("Can NOT be Removed");
        }
        System.out.println("-----------------------------------------");

        b.showDetails();

        System.out.println("-----------------------------------------");

        StoryBook sb = b.searchStoryBook("geeh");

        if(sb != null)
        {
            System.out.println("Object Found....");
            System.out.println("-----------------------------------------");
            sb.showDetails();
        }
        else
        {
            System.out.println("Object NOT Found....");
        }

        TextBook tb = b.searchTextBook("dhhhj");

        if(tb != null)
        {
            System.out.println("Object Found....");
            System.out.println("-----------------------------------------");
            tb.showDetails();
        }
        else
        {
            System.out.println("Object NOT Found....");
        }
        System.out.println("-----------------------------------------");

    }
}
