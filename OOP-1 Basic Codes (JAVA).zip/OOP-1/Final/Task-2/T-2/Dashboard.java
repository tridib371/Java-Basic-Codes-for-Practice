import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;  
public class Dashboard implements ActionListener
{  
      
   
	JButton addUser;
    JButton deletUser;
    JButton logoutBtn;
	
    JTextArea display;
    
	JFrame frame;
	
    Dashboard()
	{  
      
		frame = new JFrame ("Dashboard");
		
     
        addUser = new JButton ("Add User");
		deletUser = new JButton ("Delet User");
		logoutBtn = new JButton ("Logout");
        
        display = new JTextArea ("User ID : 1234");
        
      
        frame.add (addUser);
		frame.add (deletUser);
		frame.add (logoutBtn);

        frame.add (display);
		
    

        
        addUser.setBounds (35, 30, 120, 30);
		deletUser.setBounds (35, 90, 120, 30);
		logoutBtn.setBounds (525, 5, 75, 20);
        
        display.setBounds (35, 180, 380, 90);
        
		display.setVisible(false);
		
		addUser.addActionListener(this);
		logoutBtn.addActionListener(this);
		deletUser.addActionListener(this);
		
		
        
        frame.setSize (624, 329);
		frame.setLocationRelativeTo(null);
        frame.setLayout (null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setVisible (true);
    }     

	public void actionPerformed(ActionEvent e) 
	{  
			 
		if(e.getSource()==logoutBtn)
		{  
			new Login();
			frame.setVisible(false);			
		}
		
		else if(e.getSource()==addUser)
		{  
			display.setVisible(true);						
		}
		
		else if(e.getSource()==deletUser)
		{  
			display.setVisible(false);						
		}
		
	}      
}