import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import static javax.swing.JOptionPane.showMessageDialog;
public class Login implements ActionListener
{
	private JButton loginB, signB, forgotB;
	private JLabel userNL,userPL;
	private JTextField userF;
	private JPasswordField passF;
	private JFrame frame;
	
	User u1,u2,u3,u4,u5;
	User users[];
	
	
	Login()
	{
		u1 = new User("", "");
		users = new User[5];
		users[0] = u1;
		
		
		frame = new JFrame("Login");
		
		
		loginB = new JButton("Login");
        signB = new JButton("Sing Up");
        forgotB = new JButton("Forgot password?");
        userNL = new JLabel("Username:");
        userPL = new JLabel("Password:");
        userF = new JTextField();
        passF = new JPasswordField();
		
		
		loginB.setBounds(150,185,150,30);
		signB.setBounds(305,185,150,30);
		forgotB.setBounds(205,235,140,30);
		userNL.setBounds(150,105,100,25);
		userPL.setBounds(150,145,100,25);
		userF.setBounds(305,105,160,25);
		passF.setBounds(305,145,160,25);
		
		
		loginB.addActionListener(this);
		forgotB.addActionListener(this);
		
	
		loginB.setCursor(new Cursor(Cursor.HAND_CURSOR));
		signB.setCursor(new Cursor(Cursor.HAND_CURSOR));
		forgotB.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		
		frame.add(loginB);
		frame.add(signB);
		frame.add(forgotB);
		frame.add(userNL);
		frame.add(userPL);
		frame.add(userF);
		frame.add(passF);
		
		
        frame.setSize (624, 329);
        frame.setLayout (null);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);;
		frame.getContentPane();
		frame.setVisible (true);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == loginB)
		{
			String user = userF.getText();
			String pass = passF.getText();
			
			int a = 0;
			for(int i = 0; i<users.length; i++)
			{
				if(user.equals(users[i].getUsername()) && pass.equals(users[i].getPassword()))
				{
					a = 1;
					break;
				}
			}
			if (a == 1)
			{
				new Dashboard();
				frame.setVisible(false);
			}
			else
			{
				showMessageDialog(null, "Username or Password wrong");
			}
		}
		
	}
}